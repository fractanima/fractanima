# Fractanima Frontend

This folder contains the React-based frontend.