# Fractanima Backend

This folder contains the Node.js backend.